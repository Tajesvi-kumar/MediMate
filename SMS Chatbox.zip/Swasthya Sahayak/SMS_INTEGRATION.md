# SMS Integration for Swasthya Sahayak

## Overview
Swasthya Sahayak now supports SMS-based interaction for users with basic phones without internet access. The system provides health information through a simple text-based menu system.

## Features

### SMS Conversation Flow
- **Language Selection**: English/Kannada support
- **Menu-driven Navigation**: Simple numbered options (1, 2, 3...)
- **Health Topics**: 
  - Maternal Health
  - Child Immunization
  - Hygiene & Sanitation
  - Dengue Prevention
  - Emergency Contacts
  - Health Tips

### SMS Commands
- **START/RESET/RESTART**: Begin new conversation
- **MENU**: Return to main menu
- **1-6**: Navigate menu options
- **Case-insensitive**: Commands work in any case

### Technical Implementation

#### Endpoints
1. **`/sms/webhook`** (POST): Production webhook for SMS gateways
2. **`/sms/test`** (POST): Testing endpoint without SMS gateway
3. **`/sms`** (GET): Web-based SMS testing interface
4. **`/api/sms/sessions`** (GET): View all SMS sessions
5. **`/api/sms/sessions/<phone>`** (GET): View specific session

#### SMS Gateway Integration
The webhook endpoint accepts various SMS gateway formats:
```json
{
  "from": "+919876543210",
  "text": "1",
  "sender": "+919876543210",
  "message": "Hello"
}
```

#### Session Management
- Phone number-based sessions
- Conversation state tracking
- History logging
- Analytics integration

### Message Format
Messages are optimized for SMS (160 character limit):
- Concise health information
- Clear navigation instructions
- Essential details only
- Bilingual support

### Example SMS Conversation

**User**: START
**Bot**: Namaste! Welcome to Swasthya Sahayak. Choose language:
1.English
2.Kannada
Reply with 1 or 2

**User**: 1
**Bot**: Health Topics:
1.Maternal Health
2.Child Vaccines
3.Hygiene
4.Dengue
5.Emergency
6.Health Tips
Reply 1-6

**User**: 1
**Bot**: Maternal Health:
1.Pregnancy Timeline
2.Nutrition
3.Warning Signs
4.Doctor Visits
Reply 1-4

**User**: 2
**Bot**: Pregnancy Nutrition:
Essential: Folic acid, Iron, Calcium, Protein
Avoid: Raw meat, unpasteurized dairy, alcohol
Drink 8-10 glasses water daily
Reply MENU for main menu

## Setup Instructions

### 1. Testing (No SMS Gateway Required)
```bash
# Start the server
python app.py

# Visit SMS test page
http://127.0.0.1:5000/sms

# Or test via API
curl -X POST http://127.0.0.1:5000/sms/test \
  -H "Content-Type: application/json" \
  -d '{"phone": "+919876543210", "message": "1"}'
```

### 2. Production SMS Gateway Integration

#### Option A: Twilio
```python
# Configure webhook URL: https://yourdomain.com/sms/webhook
# Twilio will POST to this endpoint with:
{
  "From": "+919876543210",
  "Body": "Hello"
}
```

#### Option B: TextLocal
```python
# Configure webhook URL: https://yourdomain.com/sms/webhook
# TextLocal will POST with:
{
  "sender": "+919876543210",
  "message": "Hello"
}
```

#### Option C: Custom SMS Provider
The webhook endpoint accepts multiple field names:
- Phone: `from`, `sender`, `phone`
- Message: `text`, `message`, `body`

### 3. Environment Setup
```bash
# Install dependencies
pip install Flask

# Set environment variables (production)
export FLASK_ENV=production
export SMS_WEBHOOK_SECRET=your_secret_key

# Run server
python app.py
```

## Data Storage

### SMS Sessions (`sms_sessions.json`)
```json
{
  "919876543210": {
    "current_node": "menu_en",
    "conversation_history": [
      {
        "timestamp": "2025-09-27T01:00:00",
        "user_input": "1",
        "bot_response": "Health Topics...",
        "node": "menu_en"
      }
    ],
    "last_activity": "2025-09-27T01:00:00"
  }
}
```

### Analytics Integration
SMS conversations are tracked in the same analytics system:
- Node visit counts
- Daily usage statistics
- Popular conversation paths

## Limitations & Considerations

### SMS Constraints
- 160 character limit per message
- No rich formatting (emojis may not display)
- Potential delivery delays
- Cost per message

### Content Adaptations
- Shortened medical information
- Essential details only
- Clear navigation instructions
- Bilingual abbreviations

### Technical Considerations
- Session timeout handling
- Invalid input graceful handling
- Rate limiting (prevent spam)
- Message delivery confirmation

## Monitoring & Analytics

### Available Metrics
- SMS session count
- Popular health topics
- Language preferences
- Conversation completion rates
- Error rates

### Endpoints for Monitoring
```bash
# View all sessions
GET /api/sms/sessions

# View specific session
GET /api/sms/sessions/919876543210

# View analytics
GET /api/analytics
```

## Future Enhancements

### Planned Features
1. **USSD Integration**: For feature phones
2. **Voice Response**: Audio messages
3. **Scheduled Reminders**: Vaccination alerts
4. **Location-based Services**: Nearby hospitals
5. **Multi-language Support**: Additional Indian languages

### Integration Possibilities
1. **Government Health Systems**: ASHA worker integration
2. **Hospital Systems**: Appointment booking
3. **Pharmacy Networks**: Medicine availability
4. **Emergency Services**: Direct 108 integration

## Security & Privacy

### Data Protection
- Phone numbers are cleaned and stored securely
- Conversation history is anonymized for analytics
- No personal health data is stored permanently
- GDPR/Privacy compliance considerations

### Authentication
- Optional webhook secret validation
- Rate limiting per phone number
- Spam detection and blocking

## Support & Maintenance

### Common Issues
1. **Messages not delivering**: Check SMS gateway configuration
2. **Session not found**: User may need to send START
3. **Invalid responses**: Check conversation flow logic

### Debugging
```bash
# Check SMS sessions
curl http://127.0.0.1:5000/api/sms/sessions

# Test specific conversation
curl -X POST http://127.0.0.1:5000/sms/test \
  -H "Content-Type: application/json" \
  -d '{"phone": "test", "message": "START"}'
```

## Contact & Contribution
For SMS gateway integration support or feature requests, please refer to the main project documentation.
