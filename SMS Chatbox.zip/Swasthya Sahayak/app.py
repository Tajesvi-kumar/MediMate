from flask import Flask, render_template, request, jsonify, session
import json
import os
from datetime import datetime
import uuid
import re


app = Flask(__name__)
app.secret_key = 'swasthya_sahayak_secret_key_2024'  # Change this in production

# Simple file-based storage for analytics
ANALYTICS_FILE = 'analytics.json'
SMS_SESSIONS_FILE = 'sms_sessions.json'

# SMS-compatible conversation flow (simplified for 160 character limit)
SMS_CONVERSATION = {
    "start": {
        "message": "Namaste! Welcome to Swasthya Sahayak. Choose language:\n1.English\n2.Kannada\nReply with 1 or 2",
        "options": {"1": "menu_en", "2": "menu_kn"}
    },
    "menu_en": {
        "message": "Health Topics:\n1.Maternal Health\n2.Child Vaccines\n3.Hygiene\n4.Dengue\n5.Emergency\n6.Health Tips\nReply 1-6",
        "options": {"1": "maternal_en", "2": "immuno_en", "3": "hygiene_en", "4": "dengue_en", "5": "emergency_en", "6": "tips_en"}
    },
    "menu_kn": {
        "message": "ಆರೋಗ್ಯ ವಿಷಯಗಳು:\n1.ಪ್ರಸವ ಸ್ವಾಸ್ಥ್ಯ\n2.ಮಗುವಿನ ಲಸಿಕೆ\n3.ಸ್ವಚ್ಛತೆ\n4.ಡೆಂಗ್ಯೂ\n5.ತುರ್ತು\n6.ಸಲಹೆಗಳು\n1-6 ಉತ್ತರಿಸಿ",
        "options": {"1": "maternal_kn", "2": "immuno_kn", "3": "hygiene_kn", "4": "dengue_kn", "5": "emergency_kn", "6": "tips_kn"}
    },
    "maternal_en": {
        "message": "Maternal Health:\n1.Pregnancy Timeline\n2.Nutrition\n3.Warning Signs\n4.Doctor Visits\nReply 1-4",
        "options": {"1": "pregnancy_timeline_en", "2": "pregnancy_nutrition_en", "3": "pregnancy_warnings_en", "4": "pregnancy_doctor_en"}
    },
    "pregnancy_timeline_en": {
        "message": "Pregnancy Timeline:\n1st Trimester(0-12wks):Heart beats, organs form\n2nd(13-26wks):Baby moves, gender known\n3rd(27-40wks):Weight gain, birth prep\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "pregnancy_nutrition_en": {
        "message": "Pregnancy Nutrition:\nEssential: Folic acid, Iron, Calcium, Protein\nAvoid: Raw meat, unpasteurized dairy, alcohol\nDrink 8-10 glasses water daily\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "pregnancy_warnings_en": {
        "message": "Warning Signs - Call Doctor:\nSevere abdominal pain\nHeavy bleeding\nSevere headaches\nSwelling face/hands\nHigh fever over 100.4°F\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "pregnancy_doctor_en": {
        "message": "Doctor Visits:\nMonthly(4-28wks)\nEvery 2 weeks(28-36wks)\nWeekly(36-40wks)\nCheck: BP, weight, heartbeat, growth\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "immuno_en": {
        "message": "Child Vaccines:\n1.Schedule\n2.Vaccine Details\n3.Safety Info\n4.Tracker\nReply 1-4",
        "options": {"1": "immuno_schedule_en", "2": "immuno_vaccines_en", "3": "immuno_safety_en", "4": "immuno_tracker_en"}
    },
    "immuno_schedule_en": {
        "message": "Vaccine Schedule:\nBirth: BCG, HepB, OPV\n6wks: DPT, HepB, OPV, Hib\n10wks: DPT, HepB, OPV, Hib\n14wks: DPT, OPV, Hib\n9mths: Measles, VitA\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "immuno_vaccines_en": {
        "message": "Vaccines Explained:\nBCG: Tuberculosis\nDPT: Diphtheria, Pertussis, Tetanus\nHepB: Liver infection\nOPV: Polio\nHib: Meningitis\nMMR: Measles, Mumps, Rubella\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "immuno_safety_en": {
        "message": "Vaccine Safety:\nCommon side effects: Soreness, mild fever, fussiness\nUsually last 1-2 days\nCall doctor if: High fever, severe reaction, unusual crying\nVaccines are very safe\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "immuno_tracker_en": {
        "message": "Vaccine Tracker:\nKeep record of:\n- Date of each vaccine\n- Vaccine name & batch\n- Next due date\n- Side effects\nTake photos of records\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "hygiene_en": {
        "message": "Hygiene Topics:\n1.Personal Hygiene\n2.Home Sanitation\n3.Water Safety\n4.Food Safety\nReply 1-4",
        "options": {"1": "hygiene_personal_en", "2": "hygiene_home_en", "3": "hygiene_water_en", "4": "hygiene_food_en"}
    },
    "hygiene_personal_en": {
        "message": "Personal Hygiene:\nHands: Wash 20 sec with soap\nTeeth: Brush 2x daily, fluoride paste\nBody: Daily bath with soap\nNails: Clean & trimmed\nClothes: Clean daily\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "hygiene_home_en": {
        "message": "Home Sanitation:\nDaily: Sweep, mop, clean surfaces\nKitchen: Clean dishes, separate raw/cooked food\nToilet: Keep clean, wash hands after\nBedroom: Change sheets weekly\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "hygiene_water_en": {
        "message": "Water Safety:\nUse treated water when possible\nBoil 1 min if unsure\nStore in clean covered containers\nDon't touch water with hands\nUse clean ladle to pour\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "hygiene_food_en": {
        "message": "Food Safety:\nWash hands before cooking\nSeparate raw & cooked food\nCook meat to proper temperature\nRefrigerate perishables quickly\nDon't leave food out >2 hours\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "dengue_en": {
        "message": "Dengue Info:\n1.Symptoms\n2.Prevention\nReply 1 or 2",
        "options": {"1": "dengue_symptoms_en", "2": "dengue_prevention_en"}
    },
    "dengue_symptoms_en": {
        "message": "Dengue Symptoms:\nSudden high fever 104°F\nSevere headache, eye pain\nMuscle & joint pains\nNausea, vomiting\nSkin rash\n⚠️ Not medical diagnosis\nCall doctor immediately\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "dengue_prevention_en": {
        "message": "Dengue Prevention:\n1.Remove stagnant water weekly\n2.Use mosquito repellent\n3.Wear long sleeves/pants\n4.Sleep under mosquito net\n5.Clean water coolers, pots\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "emergency_en": {
        "message": "Emergency Numbers:\n108: Ambulance\n102: Ambulance Alt\n104: Health Helpline\n1098: Child Helpline\nCall for: Chest pain, unconsciousness, severe bleeding, stroke signs\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    "tips_en": {
        "message": "Health Tips:\nMorning: Water, stretch, breakfast\nNutrition: 5-6 meals, fruits/veggies\nExercise: 30 min daily, 10k steps\nSleep: 7-8 hours, consistent time\nMental: Deep breathing, nature time\nReply MENU for main menu",
        "options": {"MENU": "menu_en"}
    },
    # Kannada SMS conversations
    "maternal_kn": {
        "message": "ಪ್ರಸವ ಸ್ವಾಸ್ಥ್ಯ:\n1.ಗರ್ಭಧಾರಣೆಯ ಸಮಯ\n2.ಪೋಷಣೆ\n3.ಎಚ್ಚರಿಕೆಯ ಚಿಹ್ನೆಗಳು\n4.ವೈದ್ಯರ ಭೇಟಿ\n1-4 ಉತ್ತರಿಸಿ",
        "options": {"1": "pregnancy_timeline_kn", "2": "pregnancy_nutrition_kn", "3": "pregnancy_warnings_kn", "4": "pregnancy_doctor_kn"}
    },
    "pregnancy_timeline_kn": {
        "message": "ಗರ್ಭಧಾರಣೆಯ ಸಮಯ:\n1ನೇ ತ್ರೈಮಾಸಿಕ(0-12ವಾರ):ಹೃದಯ ಬಡಿತ, ಅಂಗಗಳು\n2ನೇ(13-26ವಾರ):ಮಗು ಚಲನೆ, ಲಿಂಗ\n3ನೇ(27-40ವಾರ):ತೂಕ, ಜನನ ಸಿದ್ಧತೆ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "pregnancy_nutrition_kn": {
        "message": "ಗರ್ಭಾವಸ್ಥೆಯ ಪೋಷಣೆ:\nಅಗತ್ಯ: ಫೋಲಿಕ್ ಆಮ್ಲ, ಕಬ್ಬಿಣ, ಕ್ಯಾಲ್ಸಿಯಂ\nತಪ್ಪಿಸಿ: ಕಚ್ಚಾ ಮಾಂಸ, ಮದ್ಯ\nದಿನಕ್ಕೆ 8-10 ಗ್ಲಾಸ್ ನೀರು\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "pregnancy_warnings_kn": {
        "message": "ಎಚ್ಚರಿಕೆಯ ಚಿಹ್ನೆಗಳು:\nತೀವ್ರ ಹೊಟ್ಟೆ ನೋವು\nತೀವ್ರ ರಕ್ತಸ್ರಾವ\nತೀವ್ರ ತಲೆನೋವು\nಮುಖ/ಕೈಗಳ ಊತ\n100.4°F+ ಜ್ವರ\nವೈದ್ಯರನ್ನು ಕರೆಯಿರಿ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "pregnancy_doctor_kn": {
        "message": "ವೈದ್ಯರ ಭೇಟಿ:\nಮಾಸಿಕ(4-28ವಾರ)\n2 ವಾರಕ್ಕೊಮ್ಮೆ(28-36ವಾರ)\nವಾರಕ್ಕೊಮ್ಮೆ(36-40ವಾರ)\nಪರಿಶೀಲನೆ: BP, ತೂಕ, ಹೃದಯಬಡಿತ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "immuno_kn": {
        "message": "ಮಗುವಿನ ಲಸಿಕೆ:\n1.ವೇಳಾಪಟ್ಟಿ\n2.ಲಸಿಕೆ ವಿವರಗಳು\n3.ಸುರಕ್ಷತೆ\n4.ಟ್ರ್ಯಾಕರ್\n1-4 ಉತ್ತರಿಸಿ",
        "options": {"1": "immuno_schedule_kn", "2": "immuno_vaccines_kn", "3": "immuno_safety_kn", "4": "immuno_tracker_kn"}
    },
    "immuno_schedule_kn": {
        "message": "ಲಸಿಕೆ ವೇಳಾಪಟ್ಟಿ:\nಜನನ: BCG, ಹೆಪB, OPV\n6ವಾರ: DPT, ಹೆಪB, OPV, Hib\n10ವಾರ: DPT, ಹೆಪB, OPV, Hib\n14ವಾರ: DPT, OPV, Hib\n9ತಿಂಗಳು: ಅಂಟುಜ್ವರ, ವಿಟA\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "immuno_vaccines_kn": {
        "message": "ಲಸಿಕೆಗಳು:\nBCG: ಕ್ಷಯರೋಗ\nDPT: ಡಿಫ್ತೀರಿಯಾ, ಟೆಟನಸ್\nಹೆಪB: ಯಕೃತ್ತು ಸೋಂಕು\nOPV: ಪೋಲಿಯೋ\nHib: ಮೆನಿಂಜೈಟಿಸ್\nMMR: ಅಂಟುಜ್ವರ, ಗಂಟಲುನೋವು\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "immuno_safety_kn": {
        "message": "ಲಸಿಕೆ ಸುರಕ್ಷತೆ:\nಸಾಮಾನ್ಯ ಪರಿಣಾಮಗಳು: ನೋವು, ಸೌಮ್ಯ ಜ್ವರ\n1-2 ದಿನಗಳವರೆಗೆ ಇರುತ್ತದೆ\nವೈದ್ಯರನ್ನು ಕರೆಯಿರಿ: ಹೆಚ್ಚಿನ ಜ್ವರ, ತೀವ್ರ ಪ್ರತಿಕ್ರಿಯೆ\nಲಸಿಕೆಗಳು ಬಹಳ ಸುರಕ್ಷಿತ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "immuno_tracker_kn": {
        "message": "ಲಸಿಕೆ ಟ್ರ್ಯಾಕರ್:\nರೆಕಾರ್ಡ್ ಇಡಿ:\n- ಪ್ರತಿ ಲಸಿಕೆಯ ದಿನಾಂಕ\n- ಲಸಿಕೆಯ ಹೆಸರು\n- ಮುಂದಿನ ದಿನಾಂಕ\n- ಪರಿಣಾಮಗಳು\nರೆಕಾರ್ಡ್ ಫೋಟೋ ತೆಗೆದುಕೊಳ್ಳಿ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "hygiene_kn": {
        "message": "ಸ್ವಚ್ಛತೆ ವಿಷಯಗಳು:\n1.ವೈಯಕ್ತಿಕ ಸ್ವಚ್ಛತೆ\n2.ಮನೆ ನೈರ್ಮಲ್ಯ\n3.ನೀರು ಸುರಕ್ಷತೆ\n4.ಆಹಾರ ಸುರಕ್ಷತೆ\n1-4 ಉತ್ತರಿಸಿ",
        "options": {"1": "hygiene_personal_kn", "2": "hygiene_home_kn", "3": "hygiene_water_kn", "4": "hygiene_food_kn"}
    },
    "hygiene_personal_kn": {
        "message": "ವೈಯಕ್ತಿಕ ಸ್ವಚ್ಛತೆ:\nಕೈಗಳು: 20 ಸೆಕೆಂಡು ಸಾಬೂನಿನಿಂದ ತೊಳೆಯಿರಿ\nಹಲ್ಲುಗಳು: ದಿನಕ್ಕೆ 2 ಬಾರಿ ಚಿಕ್ಕಿಸಿ\nದೇಹ: ದೈನಂದಿನ ಸ್ನಾನ\nಉಗುರುಗಳು: ಸ್ವಚ್ಛ ಮತ್ತು ಕತ್ತರಿಸಿ\nಬಟ್ಟೆಗಳು: ದೈನಂದಿನ ಸ್ವಚ್ಛ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "hygiene_home_kn": {
        "message": "ಮನೆ ನೈರ್ಮಲ್ಯ:\nದೈನಂದಿನ: ಗುಡಿಸಿ, ಒರೆಸಿ, ಮೇಲ್ಮೈಗಳು\nಅಡುಗೆ: ಪಾತ್ರೆಗಳು, ಕಚ್ಚಾ/ಬೇಯಿಸಿದ ಆಹಾರ ಬೇರ್ಪಡಿಸಿ\nಶೌಚಾಲಯ: ಸ್ವಚ್ಛ ಇಡಿ, ಕೈಗಳು ತೊಳೆಯಿರಿ\nಹಾಸಿಗೆ: ವಾರಕ್ಕೊಮ್ಮೆ ಚಾದರಗಳು\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "hygiene_water_kn": {
        "message": "ನೀರು ಸುರಕ್ಷತೆ:\nಸಾಧ್ಯವಾದಾಗ ಚಿಕಿತ್ಸೆ ನೀರು ಬಳಸಿ\nಅನಿಶ್ಚಿತವಾಗಿದ್ದರೆ 1 ನಿಮಿಷ ಕುದಿಸಿ\nಸ್ವಚ್ಛ ಮುಚ್ಚಿದ ಪಾತ್ರೆಗಳಲ್ಲಿ ಸಂಗ್ರಹಿಸಿ\nಕೈಗಳಿಂದ ನೀರನ್ನು ಮುಟ್ಟಬೇಡಿ\nಸ್ವಚ್ಛ ಲಾಡಲ್ ಬಳಸಿ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "hygiene_food_kn": {
        "message": "ಆಹಾರ ಸುರಕ್ಷತೆ:\nಅಡುಗೆ ಮೊದಲು ಕೈಗಳು ತೊಳೆಯಿರಿ\nಕಚ್ಚಾ ಮತ್ತು ಬೇಯಿಸಿದ ಆಹಾರ ಬೇರ್ಪಡಿಸಿ\nಮಾಂಸವನ್ನು ಸರಿಯಾದ ತಾಪಮಾನದಲ್ಲಿ ಬೇಯಿಸಿ\nನಶಿಸುವ ಆಹಾರಗಳನ್ನು ತಕ್ಷಣ ಶೀತಲಗೊಳಿಸಿ\nಆಹಾರವನ್ನು 2 ಗಂಟೆಗಿಂತ ಹೆಚ್ಚು ಹೊರಗೆ ಬಿಡಬೇಡಿ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "dengue_kn": {
        "message": "ಡೆಂಗ್ಯೂ ಮಾಹಿತಿ:\n1.ಲಕ್ಷಣಗಳು\n2.ತಡೆಗಟ್ಟುವಿಕೆ\n1 ಅಥವಾ 2 ಉತ್ತರಿಸಿ",
        "options": {"1": "dengue_symptoms_kn", "2": "dengue_prevention_kn"}
    },
    "dengue_symptoms_kn": {
        "message": "ಡೆಂಗ್ಯೂ ಲಕ್ಷಣಗಳು:\nಹಠಾತ್ ಹೆಚ್ಚಿನ ಜ್ವರ 104°F\nತೀವ್ರ ತಲೆನೋವು, ಕಣ್ಣು ನೋವು\nಸ್ನಾಯು ಮತ್ತು ಕೀಲು ನೋವು\nವಾಂತಿ, ವಾಂತಿ\nಚರ್ಮದ ದದ್ದು\n⚠️ ವೈದ್ಯಕೀಯ ರೋಗನಿರ್ಣಯವಲ್ಲ\nತಕ್ಷಣ ವೈದ್ಯರನ್ನು ಕರೆಯಿರಿ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "dengue_prevention_kn": {
        "message": "ಡೆಂಗ್ಯೂ ತಡೆಗಟ್ಟುವಿಕೆ:\n1.ನಿಶ್ಚಲ ನೀರನ್ನು ವಾರಕ್ಕೊಮ್ಮೆ ತೆಗೆದುಹಾಕಿ\n2.ಸೊಳ್ಳೆ ವಿಕರ್ಷಕ ಬಳಸಿ\n3.ಉದ್ದ ತೋಳಿನ ಬಟ್ಟೆಗಳು ಧರಿಸಿ\n4.ಸೊಳ್ಳೆ ಬಲೆಯ ಕೆಳಗೆ ಮಲಗಿ\n5.ನೀರಿನ ಕೂಲರ್ಗಳು, ಮಡಕೆಗಳು ಸ್ವಚ್ಛಗೊಳಿಸಿ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "emergency_kn": {
        "message": "ತುರ್ತು ಸಂಖ್ಯೆಗಳು:\n108: ಆಂಬ್ಯುಲೆನ್ಸ್\n102: ಆಂಬ್ಯುಲೆನ್ಸ್ ಪರ್ಯಾಯ\n104: ಆರೋಗ್ಯ ಹೆಲ್ಪ್ಲೈನ್\n1098: ಮಕ್ಕಳ ಹೆಲ್ಪ್ಲೈನ್\nಕರೆಯಿರಿ: ಎದೆ ನೋವು, ಅಜ್ಞಾನ, ತೀವ್ರ ರಕ್ತಸ್ರಾವ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    },
    "tips_kn": {
        "message": "ಆರೋಗ್ಯ ಸಲಹೆಗಳು:\nಬೆಳಿಗ್ಗೆ: ನೀರು, ಸ್ಟ್ರೆಚ್, ಉಪಹಾರ\nಪೋಷಣೆ: 5-6 ಊಟಗಳು, ಹಣ್ಣುಗಳು\nವ್ಯಾಯಾಮ: ದಿನಕ್ಕೆ 30 ನಿಮಿಷ, 10k ಹೆಜ್ಜೆಗಳು\nನಿದ್ರೆ: 7-8 ಗಂಟೆಗಳು, ಸ್ಥಿರ ಸಮಯ\nಮಾನಸಿಕ: ಆಳವಾದ ಉಸಿರಾಟ, ಪ್ರಕೃತಿ ಸಮಯ\nಮುಖ್ಯ ಮೆನುಗೆ MENU ಉತ್ತರಿಸಿ",
        "options": {"MENU": "menu_kn"}
    }
}

def load_analytics():
    if os.path.exists(ANALYTICS_FILE):
        with open(ANALYTICS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        'sessions': {},
        'conversation_stats': {},
        'daily_stats': {}
    }

def save_analytics(data):
    with open(ANALYTICS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def load_sms_sessions():
    if os.path.exists(SMS_SESSIONS_FILE):
        with open(SMS_SESSIONS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_sms_sessions(data):
    with open(SMS_SESSIONS_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def process_sms_message(phone_number, message):
    """Process incoming SMS and return response"""
    sessions = load_sms_sessions()
    
    # Clean phone number (remove +, spaces, etc.)
    clean_phone = re.sub(r'[^\d]', '', phone_number)
    
    # Get or create session
    if clean_phone not in sessions:
        sessions[clean_phone] = {
            'current_node': 'start',
            'conversation_history': [],
            'last_activity': datetime.now().isoformat()
        }
    
    session = sessions[clean_phone]
    current_node = session['current_node']
    
    # Clean and normalize user input
    user_input = message.strip().upper()
    
    # Handle special commands
    if user_input in ['RESET', 'RESTART', 'START']:
        current_node = 'start'
        session['current_node'] = current_node
        session['conversation_history'].append({
            'timestamp': datetime.now().isoformat(),
            'user_input': user_input,
            'bot_response': 'Session reset'
        })
    else:
        # Get current conversation node
        if current_node in SMS_CONVERSATION:
            node = SMS_CONVERSATION[current_node]
            
            # Check if user input matches any option
            if user_input in node['options']:
                next_node = node['options'][user_input]
                current_node = next_node
                session['current_node'] = current_node
            else:
                # Invalid input, stay on current node
                pass
    
    # Get response message
    if current_node in SMS_CONVERSATION:
        response_message = SMS_CONVERSATION[current_node]['message']
    else:
        response_message = "Sorry, something went wrong. Reply START to begin again."
        current_node = 'start'
        session['current_node'] = current_node
    
    # Update session
    session['conversation_history'].append({
        'timestamp': datetime.now().isoformat(),
        'user_input': message,
        'bot_response': response_message,
        'node': current_node
    })
    session['last_activity'] = datetime.now().isoformat()
    
    # Save sessions
    save_sms_sessions(sessions)
    
    # Track analytics
    track_conversation(current_node, message)
    
    return response_message

def track_conversation(node_id, user_choice=None):
    analytics = load_analytics()
    
    # Track conversation node visits
    if node_id not in analytics['conversation_stats']:
        analytics['conversation_stats'][node_id] = 0
    analytics['conversation_stats'][node_id] += 1
    
    # Track daily stats
    today = datetime.now().strftime('%Y-%m-%d')
    if today not in analytics['daily_stats']:
        analytics['daily_stats'][today] = {'visits': 0, 'nodes_visited': 0}
    analytics['daily_stats'][today]['visits'] += 1
    analytics['daily_stats'][today]['nodes_visited'] += 1
    
    save_analytics(analytics)


# Conversation tree definition
# Each node contains: id, messages (list of strings or HTML), and buttons (list of {text, next_id})
CONVERSATION = {
    "start": {
        "id": "start",
        "messages": [
            "Namaste! Welcome to Swasthya Sahayak, your community health assistant. 🙏\n\nPlease choose your language.\n*ನಿಮ್ಮ ಭಾಷೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಿ.*"
        ],
        "buttons": [
            {"text": "English", "next_id": "menu_en"},
            {"text": "ಕನ್ನಡ (Kannada)", "next_id": "menu_kn"},
        ],
    },
    "menu_en": {
        "id": "menu_en",
        "messages": [
            "Great! How can I help you today? Please choose a topic below.",
        ],
        "buttons": [
            {"text": "🤰 Maternal Health", "next_id": "maternal_en"},
            {"text": "👶 Child Immunization", "next_id": "immuno_en"},
            {"text": "🧼 Hygiene & Sanitation", "next_id": "hygiene_en"},
            {"text": "🦟 Dengue Symptoms & Prevention", "next_id": "dengue_start_en"},
            {"text": "🚨 Emergency Contacts", "next_id": "emergency_en"},
            {"text": "💡 Health Tips", "next_id": "tips_en"},
        ],
    },
    "dengue_start_en": {
        "id": "dengue_start_en",
        "messages": [
            "You've selected <strong>Dengue Symptoms & Prevention</strong>. Dengue is a viral infection transmitted by the bite of an infected Aedes mosquito.",
            '<img src="https://upload.wikimedia.org/wikipedia/commons/6/6d/Aedes_aegypti.jpg" alt="Aedes mosquito" style="max-width:100%; border-radius:8px; margin:6px 0;" />',
            "What would you like to know?",
        ],
        "buttons": [
            {"text": "See Common Symptoms", "next_id": "dengue_symptoms_en"},
            {"text": "Learn How to Prevent Dengue", "next_id": "dengue_prevention_en"},
        ],
    },
    "dengue_symptoms_en": {
        "id": "dengue_symptoms_en",
        "messages": [
            "Common symptoms of Dengue can include:\n• Sudden high fever (104°F / 40°C)\n• Severe headache, pain behind the eyes\n• Muscle and joint pains\n• Nausea or vomiting\n• Skin rash\n\n⚠️ <strong>Important:</strong> This is for information only and is <strong>not a medical diagnosis</strong>. Please consult a doctor immediately if you or a family member have these symptoms.",
        ],
        "buttons": [
            {"text": "Show Prevention Tips", "next_id": "dengue_prevention_en"},
            {"text": "Go to Main Menu", "next_id": "menu_en"},
        ],
    },
    "dengue_prevention_en": {
        "id": "dengue_prevention_en",
        "messages": [
            "Prevention is the best protection! You can prevent dengue by stopping mosquitoes from breeding.",
            "1. <strong>Remove Stagnant Water:</strong> Empty and clean water coolers, pots, and buckets at least once a week.",
            "2. <strong>Use Repellent:</strong> Apply mosquito repellent on exposed skin.",
            "3. <strong>Wear Protective Clothing:</strong> Wear long-sleeved shirts and pants.",
            "4. <strong>Use Mosquito Nets:</strong> Sleep under a net, especially during the day.",
        ],
        "buttons": [
            {"text": "Go to Main Menu", "next_id": "menu_en"},
            {"text": "End Chat", "next_id": "end_en"},
        ],
    },
    # Maternal Health Flow
    "maternal_en": {
        "id": "maternal_en",
        "messages": [
            "🤰 <strong>Maternal Health Support</strong>\n\nI'm here to help you with pregnancy and maternal health information. What would you like to know?",
        ],
        "buttons": [
            {"text": "📅 Pregnancy Timeline & Milestones", "next_id": "pregnancy_timeline_en"},
            {"text": "🍎 Nutrition During Pregnancy", "next_id": "pregnancy_nutrition_en"},
            {"text": "⚠️ Warning Signs to Watch", "next_id": "pregnancy_warnings_en"},
            {"text": "🏥 When to See a Doctor", "next_id": "pregnancy_doctor_en"},
            {"text": "⬅️ Back to Main Menu", "next_id": "menu_en"},
        ],
    },
    "pregnancy_timeline_en": {
        "id": "pregnancy_timeline_en",
        "messages": [
            "📅 <strong>Pregnancy Timeline & Milestones</strong>\n\nPregnancy is divided into 3 trimesters (3 months each):",
            "🌱 <strong>First Trimester (0-12 weeks):</strong>\n• Baby's heart starts beating\n• Major organs begin forming\n• Morning sickness may occur\n• First ultrasound around 8-12 weeks",
            "🌿 <strong>Second Trimester (13-26 weeks):</strong>\n• Baby starts moving (quickening)\n• Gender can be determined\n• Baby's hearing develops\n• Mother feels more energetic",
            "🌳 <strong>Third Trimester (27-40 weeks):</strong>\n• Baby gains weight rapidly\n• Baby's lungs mature\n• Baby moves into birth position\n• Preparation for delivery",
            "📝 <strong>Important:</strong> Every pregnancy is unique. Regular check-ups with your doctor are essential.",
        ],
        "buttons": [
            {"text": "🍎 Nutrition Tips", "next_id": "pregnancy_nutrition_en"},
            {"text": "⚠️ Warning Signs", "next_id": "pregnancy_warnings_en"},
            {"text": "⬅️ Back to Maternal Health", "next_id": "maternal_en"},
        ],
    },
    "pregnancy_nutrition_en": {
        "id": "pregnancy_nutrition_en",
        "messages": [
            "🍎 <strong>Nutrition During Pregnancy</strong>\n\nGood nutrition is crucial for both mother and baby:",
            "🥗 <strong>Essential Nutrients:</strong>\n• <strong>Folic Acid:</strong> Prevents birth defects (leafy greens, beans)\n• <strong>Iron:</strong> Prevents anemia (lean meat, spinach)\n• <strong>Calcium:</strong> Builds baby's bones (dairy, almonds)\n• <strong>Protein:</strong> Baby's growth (eggs, fish, lentils)",
            "🚫 <strong>Foods to Avoid:</strong>\n• Raw or undercooked meat/fish\n• Unpasteurized dairy\n• Alcohol and excessive caffeine\n• High-mercury fish (shark, swordfish)",
            "💧 <strong>Hydration:</strong> Drink 8-10 glasses of water daily",
            "⚠️ <strong>Note:</strong> Consult your doctor for personalized nutrition advice.",
        ],
        "buttons": [
            {"text": "📅 Pregnancy Timeline", "next_id": "pregnancy_timeline_en"},
            {"text": "⚠️ Warning Signs", "next_id": "pregnancy_warnings_en"},
            {"text": "⬅️ Back to Maternal Health", "next_id": "maternal_en"},
        ],
    },
    "pregnancy_warnings_en": {
        "id": "pregnancy_warnings_en",
        "messages": [
            "⚠️ <strong>Warning Signs During Pregnancy</strong>\n\nSeek immediate medical attention if you experience:",
            "🚨 <strong>Emergency Signs:</strong>\n• Severe abdominal pain\n• Heavy bleeding or spotting\n• Severe headaches with vision changes\n• Sudden swelling of face/hands\n• Persistent vomiting\n• High fever (over 100.4°F/38°C)",
            "⚠️ <strong>Other Concerning Symptoms:</strong>\n• Decreased baby movement (after 28 weeks)\n• Contractions before 37 weeks\n• Water breaking\n• Severe dizziness or fainting",
            "📞 <strong>When in doubt, contact your healthcare provider immediately!</strong>\n\nThis information is for awareness only and not a substitute for medical care.",
        ],
        "buttons": [
            {"text": "🏥 When to See Doctor", "next_id": "pregnancy_doctor_en"},
            {"text": "📅 Pregnancy Timeline", "next_id": "pregnancy_timeline_en"},
            {"text": "⬅️ Back to Maternal Health", "next_id": "maternal_en"},
        ],
    },
    "pregnancy_doctor_en": {
        "id": "pregnancy_doctor_en",
        "messages": [
            "🏥 <strong>When to See Your Doctor</strong>\n\nRegular prenatal care is essential for a healthy pregnancy:",
            "📅 <strong>Regular Check-ups:</strong>\n• Monthly visits (weeks 4-28)\n• Every 2 weeks (weeks 28-36)\n• Weekly visits (weeks 36-40)\n• More frequent if high-risk pregnancy",
            "🔍 <strong>What to Expect:</strong>\n• Blood pressure and weight monitoring\n• Baby's heartbeat check\n• Growth measurements\n• Blood and urine tests\n• Ultrasound scans",
            "📝 <strong>Questions to Ask:</strong>\n• Is my baby growing normally?\n• What should I expect in the next few weeks?\n• Are there any concerns?\n• What can I do to stay healthy?",
            "💡 <strong>Tip:</strong> Keep a list of questions for each visit!",
        ],
        "buttons": [
            {"text": "🍎 Nutrition Tips", "next_id": "pregnancy_nutrition_en"},
            {"text": "⚠️ Warning Signs", "next_id": "pregnancy_warnings_en"},
            {"text": "⬅️ Back to Maternal Health", "next_id": "maternal_en"},
        ],
    },
    
    # Child Immunization Flow
    "immuno_en": {
        "id": "immuno_en",
        "messages": [
            "👶 <strong>Child Immunization Support</strong>\n\nVaccines protect children from serious diseases. Let me help you understand the immunization schedule.",
        ],
        "buttons": [
            {"text": "📅 Immunization Schedule", "next_id": "immuno_schedule_en"},
            {"text": "💉 Common Vaccines Explained", "next_id": "immuno_vaccines_en"},
            {"text": "❓ Vaccine Safety & Side Effects", "next_id": "immuno_safety_en"},
            {"text": "📱 Track My Child's Vaccines", "next_id": "immuno_tracker_en"},
            {"text": "⬅️ Back to Main Menu", "next_id": "menu_en"},
        ],
    },
    "immuno_schedule_en": {
        "id": "immuno_schedule_en",
        "messages": [
            "📅 <strong>Immunization Schedule (India)</strong>\n\nHere's the recommended vaccination timeline:",
            "👶 <strong>Birth:</strong>\n• BCG (Tuberculosis)\n• Hepatitis B (1st dose)\n• OPV (Oral Polio Vaccine)",
            "🕐 <strong>6 weeks:</strong>\n• DPT (1st dose)\n• Hepatitis B (2nd dose)\n• OPV (2nd dose)\n• Hib (1st dose)",
            "🕑 <strong>10 weeks:</strong>\n• DPT (2nd dose)\n• Hepatitis B (3rd dose)\n• OPV (3rd dose)\n• Hib (2nd dose)",
            "🕒 <strong>14 weeks:</strong>\n• DPT (3rd dose)\n• OPV (4th dose)\n• Hib (3rd dose)",
            "🕓 <strong>9 months:</strong>\n• Measles (1st dose)\n• Vitamin A (1st dose)",
            "🕔 <strong>15-18 months:</strong>\n• DPT (Booster)\n• OPV (Booster)\n• MMR (Measles, Mumps, Rubella)",
            "📝 <strong>Note:</strong> This is a general schedule. Your doctor may adjust based on your child's needs.",
        ],
        "buttons": [
            {"text": "💉 Vaccine Details", "next_id": "immuno_vaccines_en"},
            {"text": "📱 Track Vaccines", "next_id": "immuno_tracker_en"},
            {"text": "⬅️ Back to Immunization", "next_id": "immuno_en"},
        ],
    },
    "immuno_vaccines_en": {
        "id": "immuno_vaccines_en",
        "messages": [
            "💉 <strong>Common Vaccines Explained</strong>\n\nUnderstanding what each vaccine protects against:",
            "🦠 <strong>BCG:</strong> Protects against tuberculosis (TB)\n<strong>DPT:</strong> Protects against Diphtheria, Pertussis (whooping cough), and Tetanus\n<strong>Hepatitis B:</strong> Protects against liver infection\n<strong>OPV:</strong> Protects against polio\n<strong>Hib:</strong> Protects against Haemophilus influenzae type b",
            "🌡️ <strong>MMR:</strong> Protects against Measles, Mumps, and Rubella\n<strong>Vitamin A:</strong> Boosts immune system and prevents night blindness\n<strong>Typhoid:</strong> Protects against typhoid fever\n<strong>Chickenpox:</strong> Protects against varicella",
            "🛡️ <strong>Why Vaccines Matter:</strong>\n• Prevent serious diseases\n• Protect the community (herd immunity)\n• Save lives and reduce healthcare costs\n• Some diseases are now rare thanks to vaccines",
            "📚 <strong>Remember:</strong> Vaccines are one of the greatest public health achievements!",
        ],
        "buttons": [
            {"text": "❓ Safety & Side Effects", "next_id": "immuno_safety_en"},
            {"text": "📅 Full Schedule", "next_id": "immuno_schedule_en"},
            {"text": "⬅️ Back to Immunization", "next_id": "immuno_en"},
        ],
    },
    "immuno_safety_en": {
        "id": "immuno_safety_en",
        "messages": [
            "❓ <strong>Vaccine Safety & Side Effects</strong>\n\nVaccines are thoroughly tested and very safe:",
            "✅ <strong>Common Mild Side Effects:</strong>\n• Soreness at injection site\n• Mild fever (under 101°F/38.3°C)\n• Fussiness or sleepiness\n• Loss of appetite\n• These usually last 1-2 days",
            "🛡️ <strong>Safety Measures:</strong>\n• Vaccines go through years of testing\n• Continuous monitoring for safety\n• Benefits far outweigh risks\n• Serious side effects are extremely rare",
            "⚠️ <strong>When to Call Doctor:</strong>\n• High fever (over 101°F/38.3°C)\n• Severe allergic reaction\n• Unusual crying for more than 3 hours\n• Seizures or convulsions",
            "💡 <strong>Tips:</strong>\n• Keep vaccination record safe\n• Ask questions if concerned\n• Don't delay vaccinations without medical reason",
            "📞 <strong>Remember:</strong> When in doubt, consult your pediatrician!",
        ],
        "buttons": [
            {"text": "📱 Track Vaccines", "next_id": "immuno_tracker_en"},
            {"text": "💉 Vaccine Details", "next_id": "immuno_vaccines_en"},
            {"text": "⬅️ Back to Immunization", "next_id": "immuno_en"},
        ],
    },
    "immuno_tracker_en": {
        "id": "immuno_tracker_en",
        "messages": [
            "📱 <strong>Vaccine Tracking Tool</strong>\n\nKeep track of your child's immunization progress:",
            "📋 <strong>What to Track:</strong>\n• Date of each vaccination\n• Vaccine name and batch number\n• Next due date\n• Any side effects experienced\n• Doctor's notes",
            "📝 <strong>Tracking Tips:</strong>\n• Use a vaccination card or app\n• Take photos of vaccination records\n• Set reminders for next appointments\n• Keep records in a safe place",
            "📅 <strong>Sample Tracking Format:</strong>\n<strong>Child:</strong> [Name]\n<strong>DOB:</strong> [Date]\n<strong>BCG:</strong> ✅ [Date]\n<strong>DPT-1:</strong> ✅ [Date]\n<strong>DPT-2:</strong> ⏳ Due [Date]",
            "💡 <strong>Pro Tip:</strong> Many hospitals provide digital vaccination records. Ask your healthcare provider!",
            "🔄 <strong>This is a demo tool. For actual tracking, use official health apps or maintain physical records.</strong>",
        ],
        "buttons": [
            {"text": "📅 Full Schedule", "next_id": "immuno_schedule_en"},
            {"text": "❓ Safety Info", "next_id": "immuno_safety_en"},
            {"text": "⬅️ Back to Immunization", "next_id": "immuno_en"},
        ],
    },
    
    # Hygiene & Sanitation Flow
    "hygiene_en": {
        "id": "hygiene_en",
        "messages": [
            "🧼 <strong>Hygiene & Sanitation</strong>\n\nGood hygiene practices prevent diseases and keep families healthy. What would you like to learn about?",
        ],
        "buttons": [
            {"text": "🚿 Personal Hygiene", "next_id": "hygiene_personal_en"},
            {"text": "🏠 Home Sanitation", "next_id": "hygiene_home_en"},
            {"text": "💧 Safe Water Practices", "next_id": "hygiene_water_en"},
            {"text": "🍽️ Food Safety", "next_id": "hygiene_food_en"},
            {"text": "⬅️ Back to Main Menu", "next_id": "menu_en"},
        ],
    },
    "hygiene_personal_en": {
        "id": "hygiene_personal_en",
        "messages": [
            "🚿 <strong>Personal Hygiene Best Practices</strong>\n\nGood personal hygiene prevents the spread of diseases:",
            "✋ <strong>Hand Washing:</strong>\n• Wash hands with soap for 20 seconds\n• Before eating, after using toilet\n• After touching animals or garbage\n• Use clean water and dry with clean towel",
            "🦷 <strong>Oral Hygiene:</strong>\n• Brush teeth twice daily\n• Use fluoride toothpaste\n• Replace toothbrush every 3 months\n• Floss daily if possible",
            "🛁 <strong>Body Hygiene:</strong>\n• Bathe daily with soap\n• Wash hair regularly\n• Keep nails clean and trimmed\n• Wear clean clothes daily",
            "👶 <strong>Children's Hygiene:</strong>\n• Supervise hand washing\n• Teach proper toilet habits\n• Regular bathing and nail care\n• Clean toys and surfaces",
            "💡 <strong>Remember:</strong> Good hygiene habits start young and last a lifetime!",
        ],
        "buttons": [
            {"text": "🏠 Home Sanitation", "next_id": "hygiene_home_en"},
            {"text": "💧 Water Safety", "next_id": "hygiene_water_en"},
            {"text": "⬅️ Back to Hygiene", "next_id": "hygiene_en"},
        ],
    },
    "hygiene_home_en": {
        "id": "hygiene_home_en",
        "messages": [
            "🏠 <strong>Home Sanitation</strong>\n\nA clean home environment prevents disease transmission:",
            "🧽 <strong>Daily Cleaning:</strong>\n• Sweep and mop floors\n• Clean kitchen surfaces after cooking\n• Empty trash bins regularly\n• Ventilate rooms for fresh air",
            "🚽 <strong>Toilet Hygiene:</strong>\n• Keep toilet clean and dry\n• Use toilet paper or water properly\n• Flush after each use\n• Wash hands immediately after",
            "🍽️ <strong>Kitchen Hygiene:</strong>\n• Clean dishes with soap and hot water\n• Separate raw and cooked food\n• Clean cutting boards after use\n• Store food in covered containers",
            "🛏️ <strong>Bedroom Hygiene:</strong>\n• Change bed sheets weekly\n• Air out mattresses regularly\n• Keep clothes organized and clean\n• Remove dust from surfaces",
            "🐭 <strong>Pest Control:</strong>\n• Seal food containers tightly\n• Fix leaks and standing water\n• Keep garbage covered\n• Clean up food spills immediately",
        ],
        "buttons": [
            {"text": "💧 Water Safety", "next_id": "hygiene_water_en"},
            {"text": "🍽️ Food Safety", "next_id": "hygiene_food_en"},
            {"text": "⬅️ Back to Hygiene", "next_id": "hygiene_en"},
        ],
    },
    "hygiene_water_en": {
        "id": "hygiene_water_en",
        "messages": [
            "💧 <strong>Safe Water Practices</strong>\n\nClean water is essential for health. Here's how to ensure water safety:",
            "🚰 <strong>Water Sources:</strong>\n• Use treated/municipal water when possible\n• Boil water for 1 minute if unsure\n• Use water filters or purification tablets\n• Store water in clean, covered containers",
            "💧 <strong>Water Storage:</strong>\n• Use clean, food-grade containers\n• Keep containers covered\n• Don't touch water with hands\n• Use clean ladle or tap to pour",
            "🧊 <strong>Water Treatment Methods:</strong>\n• <strong>Boiling:</strong> Bring to rolling boil for 1 minute\n• <strong>Chlorination:</strong> Add 2 drops of bleach per liter\n• <strong>Filtration:</strong> Use ceramic or carbon filters\n• <strong>UV Treatment:</strong> Use UV purification devices",
            "⚠️ <strong>Signs of Contaminated Water:</strong>\n• Unusual color, taste, or smell\n• Cloudy or murky appearance\n• Presence of particles or debris",
            "🏥 <strong>Water-Borne Diseases:</strong>\n• Cholera, Typhoid, Hepatitis A\n• Diarrhea, Dysentery\n• Prevention is better than cure!",
        ],
        "buttons": [
            {"text": "🍽️ Food Safety", "next_id": "hygiene_food_en"},
            {"text": "🚿 Personal Hygiene", "next_id": "hygiene_personal_en"},
            {"text": "⬅️ Back to Hygiene", "next_id": "hygiene_en"},
        ],
    },
    "hygiene_food_en": {
        "id": "hygiene_food_en",
        "messages": [
            "🍽️ <strong>Food Safety</strong>\n\nProper food handling prevents food poisoning and diseases:",
            "🛒 <strong>Shopping Safely:</strong>\n• Buy from clean, reputable stores\n• Check expiration dates\n• Keep raw meat separate\n• Refrigerate perishables quickly",
            "🧊 <strong>Storage Guidelines:</strong>\n• Refrigerate at 40°F (4°C) or below\n• Freeze at 0°F (-18°C) or below\n• Use within recommended time\n• Cover all stored food",
            "👨‍🍳 <strong>Food Preparation:</strong>\n• Wash hands before cooking\n• Clean all surfaces and utensils\n• Separate raw and cooked foods\n• Cook meat to proper temperature",
            "🍳 <strong>Cooking Temperatures:</strong>\n• Poultry: 165°F (74°C)\n• Ground meat: 160°F (71°C)\n• Fish: 145°F (63°C)\n• Leftovers: 165°F (74°C)",
            "🚫 <strong>Food Safety Rules:</strong>\n• Don't leave food out for more than 2 hours\n• When in doubt, throw it out\n• Don't taste food to check if it's safe\n• Keep hot food hot, cold food cold",
            "🤒 <strong>Food Poisoning Symptoms:</strong>\n• Nausea, vomiting, diarrhea\n• Stomach cramps, fever\n• Seek medical help if severe",
        ],
        "buttons": [
            {"text": "🚿 Personal Hygiene", "next_id": "hygiene_personal_en"},
            {"text": "🏠 Home Sanitation", "next_id": "hygiene_home_en"},
            {"text": "⬅️ Back to Hygiene", "next_id": "hygiene_en"},
        ],
    },
    # Kannada Language Support
    "menu_kn": {
        "id": "menu_kn",
        "messages": [
            "ಸ್ವಾಗತ! ಸ್ವಸ್ಥ್ಯ ಸಹಾಯಕದಲ್ಲಿ ನಿಮಗೆ ಸಹಾಯ ಮಾಡಲು ನಾನು ಇಲ್ಲಿದ್ದೇನೆ. 🙏\n\nಇಂದು ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು? ಕೆಳಗಿನ ವಿಷಯಗಳಲ್ಲಿ ಆಯ್ಕೆ ಮಾಡಿ.",
        ],
        "buttons": [
            {"text": "🤰 ಪ್ರಸವ ಸ್ವಾಸ್ಥ್ಯ", "next_id": "maternal_kn"},
            {"text": "👶 ಮಗುವಿನ ಲಸಿಕೆ", "next_id": "immuno_kn"},
            {"text": "🧼 ಸ್ವಚ್ಛತೆ ಮತ್ತು ನೈರ್ಮಲ್ಯ", "next_id": "hygiene_kn"},
            {"text": "🦟 ಡೆಂಗ್ಯೂ ರೋಗದ ಲಕ್ಷಣಗಳು", "next_id": "dengue_start_kn"},
            {"text": "🚨 ತುರ್ತು ಸಂಪರ್ಕಗಳು", "next_id": "emergency_kn"},
            {"text": "💡 ಆರೋಗ್ಯ ಸಲಹೆಗಳು", "next_id": "tips_kn"},
            {"text": "⬅️ English", "next_id": "menu_en"},
        ],
    },
    # Additional Kannada conversation nodes
    "maternal_kn": {
        "id": "maternal_kn",
        "messages": [
            "🤰 <strong>ಪ್ರಸವ ಸ್ವಾಸ್ಥ್ಯ ಸಹಾಯ</strong>\n\nಗರ್ಭಧಾರಣೆ ಮತ್ತು ಪ್ರಸವ ಸ್ವಾಸ್ಥ್ಯದ ಬಗ್ಗೆ ಮಾಹಿತಿ ನೀಡಲು ನಾನು ಇಲ್ಲಿದ್ದೇನೆ.",
        ],
        "buttons": [
            {"text": "📅 ಗರ್ಭಧಾರಣೆಯ ಸಮಯ", "next_id": "pregnancy_timeline_kn"},
            {"text": "🍎 ಗರ್ಭಾವಸ್ಥೆಯಲ್ಲಿ ಪೋಷಣೆ", "next_id": "pregnancy_nutrition_kn"},
            {"text": "⚠️ ಎಚ್ಚರಿಕೆಯ ಚಿಹ್ನೆಗಳು", "next_id": "pregnancy_warnings_kn"},
            {"text": "⬅️ ಮುಖ್ಯ ಮೆನು", "next_id": "menu_kn"},
        ],
    },
    "pregnancy_timeline_kn": {
        "id": "pregnancy_timeline_kn",
        "messages": [
            "📅 <strong>ಗರ್ಭಧಾರಣೆಯ ಸಮಯ ಮತ್ತು ಮೈಲಿಗಲ್ಲುಗಳು</strong>\n\nಗರ್ಭಧಾರಣೆಯನ್ನು 3 ತ್ರೈಮಾಸಿಕಗಳಾಗಿ ವಿಭಜಿಸಲಾಗಿದೆ:",
            "🌱 <strong>ಮೊದಲ ತ್ರೈಮಾಸಿಕ (0-12 ವಾರಗಳು):</strong>\n• ಮಗುವಿನ ಹೃದಯ ಬಡಿಯಲು ಪ್ರಾರಂಭಿಸುತ್ತದೆ\n• ಪ್ರಮುಖ ಅಂಗಗಳು ರೂಪಗೊಳ್ಳಲು ಪ್ರಾರಂಭಿಸುತ್ತವೆ\n• ಬೆಳಿಗ್ಗೆ ಅನಾರೋಗ್ಯ ಸಂಭವಿಸಬಹುದು",
            "🌿 <strong>ಎರಡನೇ ತ್ರೈಮಾಸಿಕ (13-26 ವಾರಗಳು):</strong>\n• ಮಗು ಚಲಿಸಲು ಪ್ರಾರಂಭಿಸುತ್ತದೆ\n• ಲಿಂಗವನ್ನು ನಿರ್ಧರಿಸಬಹುದು\n• ಮಗುವಿನ ಕೇಳುವಿಕೆ ಅಭಿವೃದ್ಧಿಯಾಗುತ್ತದೆ",
            "🌳 <strong>ಮೂರನೇ ತ್ರೈಮಾಸಿಕ (27-40 ವಾರಗಳು):</strong>\n• ಮಗು ತೂಕವನ್ನು ವೇಗವಾಗಿ ಪಡೆಯುತ್ತದೆ\n• ಮಗುವಿನ ಶ್ವಾಸಕೋಶಗಳು ಪಕ್ವವಾಗುತ್ತವೆ\n• ಜನನ ಸ್ಥಾನಕ್ಕೆ ಚಲಿಸುತ್ತದೆ",
        ],
        "buttons": [
            {"text": "🍎 ಪೋಷಣೆ ಸಲಹೆಗಳು", "next_id": "pregnancy_nutrition_kn"},
            {"text": "⚠️ ಎಚ್ಚರಿಕೆಯ ಚಿಹ್ನೆಗಳು", "next_id": "pregnancy_warnings_kn"},
            {"text": "⬅️ ಪ್ರಸವ ಸ್ವಾಸ್ಥ್ಯಕ್ಕೆ ಹಿಂತಿರುಗಿ", "next_id": "maternal_kn"},
        ],
    },
    "pregnancy_nutrition_kn": {
        "id": "pregnancy_nutrition_kn",
        "messages": [
            "🍎 <strong>ಗರ್ಭಾವಸ್ಥೆಯಲ್ಲಿ ಪೋಷಣೆ</strong>\n\nಉತ್ತಮ ಪೋಷಣೆ ತಾಯಿ ಮತ್ತು ಮಗುವಿಗೆ ಅತ್ಯಗತ್ಯ:",
            "🥗 <strong>ಅಗತ್ಯ ಪೋಷಕಾಂಶಗಳು:</strong>\n• <strong>ಫೋಲಿಕ್ ಆಮ್ಲ:</strong> ಜನ್ಮ ದೋಷಗಳನ್ನು ತಡೆಯುತ್ತದೆ\n• <strong>ಕಬ್ಬಿಣ:</strong> ರಕ್ತಹೀನತೆಯನ್ನು ತಡೆಯುತ್ತದೆ\n• <strong>ಕ್ಯಾಲ್ಸಿಯಂ:</strong> ಮಗುವಿನ ಮೂಳೆಗಳನ್ನು ನಿರ್ಮಿಸುತ್ತದೆ\n• <strong>ಪ್ರೋಟೀನ್:</strong> ಮಗುವಿನ ಬೆಳವಣಿಗೆ",
            "🚫 <strong>ತಪ್ಪಿಸಬೇಕಾದ ಆಹಾರಗಳು:</strong>\n• ಕಚ್ಚಾ ಅಥವಾ ಅಪಕ್ವ ಮಾಂಸ/ಮೀನು\n• ಪಾಶ್ಚರೀಕರಣವಾಗದ ಡೈರಿ\n• ಮದ್ಯ ಮತ್ತು ಅತಿಯಾದ ಕೆಫೀನ್",
        ],
        "buttons": [
            {"text": "📅 ಗರ್ಭಧಾರಣೆಯ ಸಮಯ", "next_id": "pregnancy_timeline_kn"},
            {"text": "⚠️ ಎಚ್ಚರಿಕೆಯ ಚಿಹ್ನೆಗಳು", "next_id": "pregnancy_warnings_kn"},
            {"text": "⬅️ ಪ್ರಸವ ಸ್ವಾಸ್ಥ್ಯಕ್ಕೆ ಹಿಂತಿರುಗಿ", "next_id": "maternal_kn"},
        ],
    },
    "pregnancy_warnings_kn": {
        "id": "pregnancy_warnings_kn",
        "messages": [
            "⚠️ <strong>ಗರ್ಭಾವಸ್ಥೆಯಲ್ಲಿ ಎಚ್ಚರಿಕೆಯ ಚಿಹ್ನೆಗಳು</strong>\n\nಕೆಳಗಿನ ಲಕ್ಷಣಗಳು ಕಂಡುಬಂದರೆ ತಕ್ಷಣ ವೈದ್ಯಕೀಯ ಸಹಾಯ ಪಡೆಯಿರಿ:",
            "🚨 <strong>ತುರ್ತು ಚಿಹ್ನೆಗಳು:</strong>\n• ತೀವ್ರ ಹೊಟ್ಟೆ ನೋವು\n• ತೀವ್ರ ರಕ್ತಸ್ರಾವ ಅಥವಾ ಚುಕ್ಕೆಗಳು\n• ದೃಷ್ಟಿ ಬದಲಾವಣೆಗಳೊಂದಿಗೆ ತೀವ್ರ ತಲೆನೋವು\n• ಮುಖ/ಕೈಗಳ ಹಠಾತ್ ಊತ\n• ನಿರಂತರ ವಾಂತಿ\n• ಹೆಚ್ಚಿನ ಜ್ವರ (100.4°F/38°C ಕ್ಕಿಂತ ಹೆಚ್ಚು)",
            "📞 <strong>ಸಂದೇಹವಿದ್ದರೆ, ತಕ್ಷಣ ನಿಮ್ಮ ಆರೋಗ್ಯ ಸೇವಾ ಪೂರೈಕೆದಾರರನ್ನು ಸಂಪರ್ಕಿಸಿ!</strong>",
        ],
        "buttons": [
            {"text": "🍎 ಪೋಷಣೆ ಸಲಹೆಗಳು", "next_id": "pregnancy_nutrition_kn"},
            {"text": "📅 ಗರ್ಭಧಾರಣೆಯ ಸಮಯ", "next_id": "pregnancy_timeline_kn"},
            {"text": "⬅️ ಪ್ರಸವ ಸ್ವಾಸ್ಥ್ಯಕ್ಕೆ ಹಿಂತಿರುಗಿ", "next_id": "maternal_kn"},
        ],
    },
    "immuno_kn": {
        "id": "immuno_kn",
        "messages": [
            "👶 <strong>ಮಗುವಿನ ಲಸಿಕೆ ಸಹಾಯ</strong>\n\nಲಸಿಕೆಗಳು ಮಕ್ಕಳನ್ನು ಗಂಭೀರ ರೋಗಗಳಿಂದ ರಕ್ಷಿಸುತ್ತವೆ.",
        ],
        "buttons": [
            {"text": "📅 ಲಸಿಕೆ ವೇಳಾಪಟ್ಟಿ", "next_id": "immuno_schedule_kn"},
            {"text": "💉 ಸಾಮಾನ್ಯ ಲಸಿಕೆಗಳು", "next_id": "immuno_vaccines_kn"},
            {"text": "❓ ಲಸಿಕೆ ಸುರಕ್ಷತೆ", "next_id": "immuno_safety_kn"},
            {"text": "⬅️ ಮುಖ್ಯ ಮೆನು", "next_id": "menu_kn"},
        ],
    },
    "immuno_schedule_kn": {
        "id": "immuno_schedule_kn",
        "messages": [
            "📅 <strong>ಲಸಿಕೆ ವೇಳಾಪಟ್ಟಿ (ಭಾರತ)</strong>\n\nಶಿಫಾರಸು ಮಾಡಲಾದ ಲಸಿಕೆ ಸಮಯ:",
            "👶 <strong>ಜನನ:</strong>\n• BCG (ಕ್ಷಯರೋಗ)\n• ಹೆಪಟೈಟಿಸ್ B (1ನೇ ಡೋಸ್)\n• OPV (ಮೌಖಿಕ ಪೋಲಿಯೋ ಲಸಿಕೆ)",
            "🕐 <strong>6 ವಾರಗಳು:</strong>\n• DPT (1ನೇ ಡೋಸ್)\n• ಹೆಪಟೈಟಿಸ್ B (2ನೇ ಡೋಸ್)\n• OPV (2ನೇ ಡೋಸ್)\n• Hib (1ನೇ ಡೋಸ್)",
            "🕑 <strong>10 ವಾರಗಳು:</strong>\n• DPT (2ನೇ ಡೋಸ್)\n• ಹೆಪಟೈಟಿಸ್ B (3ನೇ ಡೋಸ್)\n• OPV (3ನೇ ಡೋಸ್)\n• Hib (2ನೇ ಡೋಸ್)",
            "🕒 <strong>14 ವಾರಗಳು:</strong>\n• DPT (3ನೇ ಡೋಸ್)\n• OPV (4ನೇ ಡೋಸ್)\n• Hib (3ನೇ ಡೋಸ್)",
            "🕓 <strong>9 ತಿಂಗಳುಗಳು:</strong>\n• ಅಂಟುಜ್ವರ (1ನೇ ಡೋಸ್)\n• ವಿಟಮಿನ್ A (1ನೇ ಡೋಸ್)",
        ],
        "buttons": [
            {"text": "💉 ಲಸಿಕೆ ವಿವರಗಳು", "next_id": "immuno_vaccines_kn"},
            {"text": "❓ ಸುರಕ್ಷತೆ ಮಾಹಿತಿ", "next_id": "immuno_safety_kn"},
            {"text": "⬅️ ಲಸಿಕೆಗೆ ಹಿಂತಿರುಗಿ", "next_id": "immuno_kn"},
        ],
    },
    "immuno_vaccines_kn": {
        "id": "immuno_vaccines_kn",
        "messages": [
            "💉 <strong>ಸಾಮಾನ್ಯ ಲಸಿಕೆಗಳ ವಿವರಣೆ</strong>\n\nಪ್ರತಿ ಲಸಿಕೆ ಯಾವ ರೋಗದಿಂದ ರಕ್ಷಿಸುತ್ತದೆ:",
            "🦠 <strong>BCG:</strong> ಕ್ಷಯರೋಗದಿಂದ ರಕ್ಷಿಸುತ್ತದೆ\n<strong>DPT:</strong> ಡಿಫ್ತೀರಿಯಾ, ಪರ್ಟುಸಿಸ್, ಮತ್ತು ಟೆಟನಸ್\n<strong>ಹೆಪಟೈಟಿಸ್ B:</strong> ಯಕೃತ್ತಿನ ಸೋಂಕಿನಿಂದ ರಕ್ಷಿಸುತ್ತದೆ\n<strong>OPV:</strong> ಪೋಲಿಯೋದಿಂದ ರಕ್ಷಿಸುತ್ತದೆ",
            "🌡️ <strong>MMR:</strong> ಅಂಟುಜ್ವರ, ಗಂಟಲುನೋವು, ಮತ್ತು ರೂಬೆಲ್ಲಾ\n<strong>ವಿಟಮಿನ್ A:</strong> ರೋಗನಿರೋಧಕ ಶಕ್ತಿಯನ್ನು ಹೆಚ್ಚಿಸುತ್ತದೆ",
            "🛡️ <strong>ಲಸಿಕೆಗಳು ಏಕೆ ಮುಖ್ಯ:</strong>\n• ಗಂಭೀರ ರೋಗಗಳನ್ನು ತಡೆಯುತ್ತವೆ\n• ಸಮುದಾಯವನ್ನು ರಕ್ಷಿಸುತ್ತವೆ\n• ಜೀವಗಳನ್ನು ಉಳಿಸುತ್ತವೆ",
        ],
        "buttons": [
            {"text": "❓ ಸುರಕ್ಷತೆ ಮಾಹಿತಿ", "next_id": "immuno_safety_kn"},
            {"text": "📅 ಪೂರ್ಣ ವೇಳಾಪಟ್ಟಿ", "next_id": "immuno_schedule_kn"},
            {"text": "⬅️ ಲಸಿಕೆಗೆ ಹಿಂತಿರುಗಿ", "next_id": "immuno_kn"},
        ],
    },
    "immuno_safety_kn": {
        "id": "immuno_safety_kn",
        "messages": [
            "❓ <strong>ಲಸಿಕೆ ಸುರಕ್ಷತೆ ಮತ್ತು ಅಡ್ಡ ಪರಿಣಾಮಗಳು</strong>\n\nಲಸಿಕೆಗಳು ಸಂಪೂರ್ಣವಾಗಿ ಪರೀಕ್ಷಿಸಲ್ಪಟ್ಟಿವೆ ಮತ್ತು ಬಹಳ ಸುರಕ್ಷಿತ:",
            "✅ <strong>ಸಾಮಾನ್ಯ ಸೌಮ್ಯ ಅಡ್ಡ ಪರಿಣಾಮಗಳು:</strong>\n• ಚುಚ್ಚುವ ಸ್ಥಳದಲ್ಲಿ ನೋವು\n• ಸೌಮ್ಯ ಜ್ವರ (101°F/38.3°C ಕ್ಕಿಂತ ಕಡಿಮೆ)\n• ಅಸಹ್ಯ ಅಥವಾ ನಿದ್ರೆ\n• ಹಸಿವಿನ ಕೊರತೆ\n• ಇವು ಸಾಮಾನ್ಯವಾಗಿ 1-2 ದಿನಗಳವರೆಗೆ ಇರುತ್ತವೆ",
            "🛡️ <strong>ಸುರಕ್ಷತಾ ಕ್ರಮಗಳು:</strong>\n• ಲಸಿಕೆಗಳು ವರ್ಷಗಳ ಕಾಲ ಪರೀಕ್ಷಿಸಲ್ಪಡುತ್ತವೆ\n• ಸುರಕ್ಷತೆಗಾಗಿ ನಿರಂತರ ಮೇಲ್ವಿಚಾರಣೆ\n• ಪ್ರಯೋಜನಗಳು ಅಪಾಯಗಳಿಗಿಂತ ಹೆಚ್ಚು",
            "⚠️ <strong>ವೈದ್ಯರನ್ನು ಕರೆಯಬೇಕಾದಾಗ:</strong>\n• ಹೆಚ್ಚಿನ ಜ್ವರ (101°F/38.3°C ಕ್ಕಿಂತ ಹೆಚ್ಚು)\n• ತೀವ್ರ ಅಲರ್ಜಿ ಪ್ರತಿಕ್ರಿಯೆ\n• 3 ಗಂಟೆಗಳಿಗಿಂತ ಹೆಚ್ಚು ಅಸಾಮಾನ್ಯ ಅಳುವಿಕೆ",
        ],
        "buttons": [
            {"text": "💉 ಲಸಿಕೆ ವಿವರಗಳು", "next_id": "immuno_vaccines_kn"},
            {"text": "📅 ಪೂರ್ಣ ವೇಳಾಪಟ್ಟಿ", "next_id": "immuno_schedule_kn"},
            {"text": "⬅️ ಲಸಿಕೆಗೆ ಹಿಂತಿರುಗಿ", "next_id": "immuno_kn"},
        ],
    },
    "hygiene_kn": {
        "id": "hygiene_kn",
        "messages": [
            "🧼 <strong>ಸ್ವಚ್ಛತೆ ಮತ್ತು ನೈರ್ಮಲ್ಯ</strong>\n\nಉತ್ತಮ ಸ್ವಚ್ಛತೆ ಅಭ್ಯಾಸಗಳು ರೋಗಗಳನ್ನು ತಡೆಯುತ್ತವೆ ಮತ್ತು ಕುಟುಂಬಗಳನ್ನು ಆರೋಗ್ಯವಾಗಿ ಇಡುತ್ತವೆ.",
        ],
        "buttons": [
            {"text": "🚿 ವೈಯಕ್ತಿಕ ಸ್ವಚ್ಛತೆ", "next_id": "hygiene_personal_kn"},
            {"text": "🏠 ಮನೆ ನೈರ್ಮಲ್ಯ", "next_id": "hygiene_home_kn"},
            {"text": "💧 ಸುರಕ್ಷಿತ ನೀರಿನ ಅಭ್ಯಾಸಗಳು", "next_id": "hygiene_water_kn"},
            {"text": "⬅️ ಮುಖ್ಯ ಮೆನು", "next_id": "menu_kn"},
        ],
    },
    "hygiene_personal_kn": {
        "id": "hygiene_personal_kn",
        "messages": [
            "🚿 <strong>ವೈಯಕ್ತಿಕ ಸ್ವಚ್ಛತೆಯ ಉತ್ತಮ ಅಭ್ಯಾಸಗಳು</strong>\n\nಉತ್ತಮ ವೈಯಕ್ತಿಕ ಸ್ವಚ್ಛತೆ ರೋಗಗಳ ಹರಡುವಿಕೆಯನ್ನು ತಡೆಯುತ್ತದೆ:",
            "✋ <strong>ಕೈ ತೊಳೆಯುವಿಕೆ:</strong>\n• 20 ಸೆಕೆಂಡುಗಳ ಕಾಲ ಸಾಬೂನಿನಿಂದ ಕೈಗಳನ್ನು ತೊಳೆಯಿರಿ\n• ತಿನ್ನುವ ಮೊದಲು, ಶೌಚಾಲಯ ಬಳಸಿದ ನಂತರ\n• ಪ್ರಾಣಿಗಳು ಅಥವಾ ಕಸವನ್ನು ಮುಟ್ಟಿದ ನಂತರ\n• ಸ್ವಚ್ಛ ನೀರು ಬಳಸಿ ಮತ್ತು ಸ್ವಚ್ಛ ಟವೆಲ್ನಿಂದ ಒಣಗಿಸಿ",
            "🦷 <strong>ಮುಖ ಸ್ವಚ್ಛತೆ:</strong>\n• ದಿನಕ್ಕೆ ಎರಡು ಬಾರಿ ಹಲ್ಲುಗಳನ್ನು ಚಿಕ್ಕಿಸಿ\n• ಫ್ಲೋರೈಡ್ ಟೂತ್ಪೇಸ್ಟ್ ಬಳಸಿ\n• ಪ್ರತಿ 3 ತಿಂಗಳಿಗೆ ಟೂತ್ಬ್ರಷ್ ಬದಲಾಯಿಸಿ",
            "🛁 <strong>ದೇಹ ಸ್ವಚ್ಛತೆ:</strong>\n• ಸಾಬೂನಿನಿಂದ ದೈನಂದಿನ ಸ್ನಾನ\n• ನಿಯಮಿತವಾಗಿ ಕೂದಲು ತೊಳೆಯುವಿಕೆ\n• ಉಗುರುಗಳನ್ನು ಸ್ವಚ್ಛ ಮತ್ತು ಕತ್ತರಿಸಿ ಇಡುವುದು\n• ದೈನಂದಿನ ಸ್ವಚ್ಛ ಬಟ್ಟೆಗಳನ್ನು ಧರಿಸುವುದು",
        ],
        "buttons": [
            {"text": "🏠 ಮನೆ ನೈರ್ಮಲ್ಯ", "next_id": "hygiene_home_kn"},
            {"text": "💧 ನೀರು ಸುರಕ್ಷತೆ", "next_id": "hygiene_water_kn"},
            {"text": "⬅️ ಸ್ವಚ್ಛತೆಗೆ ಹಿಂತಿರುಗಿ", "next_id": "hygiene_kn"},
        ],
    },
    "hygiene_home_kn": {
        "id": "hygiene_home_kn",
        "messages": [
            "🏠 <strong>ಮನೆ ನೈರ್ಮಲ್ಯ</strong>\n\nಸ್ವಚ್ಛ ಮನೆಯ ವಾತಾವರಣ ರೋಗ ಸಂಕ್ರಮಣವನ್ನು ತಡೆಯುತ್ತದೆ:",
            "🧽 <strong>ದೈನಂದಿನ ಸ್ವಚ್ಛತೆ:</strong>\n• ನೆಲಗಳನ್ನು ಗುಡಿಸಿ ಮತ್ತು ಒರೆಸಿ\n• ಅಡುಗೆ ಮಾಡಿದ ನಂತರ ಅಡುಗೆ ಮೇಲ್ಮೈಗಳನ್ನು ಸ್ವಚ್ಛಗೊಳಿಸಿ\n• ಕಸದ ಬುಟ್ಟಿಗಳನ್ನು ನಿಯಮಿತವಾಗಿ ಖಾಲಿ ಮಾಡಿ\n• ತಾಜಾ ಗಾಳಿಗಾಗಿ ಕೋಣೆಗಳನ್ನು ಗಾಳಿ ಬಿಡಿ",
            "🚽 <strong>ಶೌಚಾಲಯ ಸ್ವಚ್ಛತೆ:</strong>\n• ಶೌಚಾಲಯವನ್ನು ಸ್ವಚ್ಛ ಮತ್ತು ಒಣವಾಗಿ ಇಡಿ\n• ಶೌಚಾಲಯದ ಕಾಗದ ಅಥವಾ ನೀರನ್ನು ಸರಿಯಾಗಿ ಬಳಸಿ\n• ಪ್ರತಿ ಬಳಕೆಯ ನಂತರ ತೊಳೆಯಿರಿ\n• ತಕ್ಷಣ ಕೈಗಳನ್ನು ತೊಳೆಯಿರಿ",
            "🍽️ <strong>ಅಡುಗೆ ಸ್ವಚ್ಛತೆ:</strong>\n• ಸಾಬೂನು ಮತ್ತು ಬಿಸಿ ನೀರಿನಿಂದ ಪಾತ್ರೆಗಳನ್ನು ಸ್ವಚ್ಛಗೊಳಿಸಿ\n• ಕಚ್ಚಾ ಮತ್ತು ಬೇಯಿಸಿದ ಆಹಾರವನ್ನು ಬೇರ್ಪಡಿಸಿ\n• ಬಳಕೆಯ ನಂತರ ಕತ್ತರಿಸುವ ಮಂಡಿಗಳನ್ನು ಸ್ವಚ್ಛಗೊಳಿಸಿ",
        ],
        "buttons": [
            {"text": "💧 ನೀರು ಸುರಕ್ಷತೆ", "next_id": "hygiene_water_kn"},
            {"text": "🚿 ವೈಯಕ್ತಿಕ ಸ್ವಚ್ಛತೆ", "next_id": "hygiene_personal_kn"},
            {"text": "⬅️ ಸ್ವಚ್ಛತೆಗೆ ಹಿಂತಿರುಗಿ", "next_id": "hygiene_kn"},
        ],
    },
    "hygiene_water_kn": {
        "id": "hygiene_water_kn",
        "messages": [
            "💧 <strong>ಸುರಕ್ಷಿತ ನೀರಿನ ಅಭ್ಯಾಸಗಳು</strong>\n\nಸ್ವಚ್ಛ ನೀರು ಆರೋಗ್ಯಕ್ಕೆ ಅತ್ಯಗತ್ಯ. ನೀರು ಸುರಕ್ಷತೆಯನ್ನು ಹೇಗೆ ಖಚಿತಪಡಿಸುವುದು:",
            "🚰 <strong>ನೀರಿನ ಮೂಲಗಳು:</strong>\n• ಸಾಧ್ಯವಾದಾಗ ಚಿಕಿತ್ಸೆ/ನಗರ ನೀರನ್ನು ಬಳಸಿ\n• ಅನಿಶ್ಚಿತವಾಗಿದ್ದರೆ 1 ನಿಮಿಷ ನೀರನ್ನು ಕುದಿಸಿ\n• ನೀರು ಫಿಲ್ಟರ್ಗಳು ಅಥವಾ ಶುದ್ಧೀಕರಣ ಟ್ಯಾಬ್ಲೆಟ್ಗಳನ್ನು ಬಳಸಿ\n• ಸ್ವಚ್ಛ, ಮುಚ್ಚಿದ ಪಾತ್ರೆಗಳಲ್ಲಿ ನೀರನ್ನು ಸಂಗ್ರಹಿಸಿ",
            "💧 <strong>ನೀರು ಸಂಗ್ರಹಣೆ:</strong>\n• ಸ್ವಚ್ಛ, ಆಹಾರ-ಶ್ರೇಣಿಯ ಪಾತ್ರೆಗಳನ್ನು ಬಳಸಿ\n• ಪಾತ್ರೆಗಳನ್ನು ಮುಚ್ಚಿ ಇಡಿ\n• ಕೈಗಳಿಂದ ನೀರನ್ನು ಮುಟ್ಟಬೇಡಿ\n• ಸ್ವಚ್ಛ ಲಾಡಲ್ ಅಥವಾ ಟ್ಯಾಪ್ ಬಳಸಿ",
            "🧊 <strong>ನೀರು ಚಿಕಿತ್ಸಾ ವಿಧಾನಗಳು:</strong>\n• <strong>ಕುದಿಸುವುದು:</strong> 1 ನಿಮಿಷ ಕುದಿಸಿ\n• <strong>ಕ್ಲೋರಿನೇಶನ್:</strong> ಲೀಟರಿಗೆ 2 ಹನಿ ಬ್ಲೀಚ್ ಸೇರಿಸಿ\n• <strong>ಫಿಲ್ಟರೇಶನ್:</strong> ಸೆರಾಮಿಕ್ ಅಥವಾ ಕಾರ್ಬನ್ ಫಿಲ್ಟರ್ಗಳನ್ನು ಬಳಸಿ",
        ],
        "buttons": [
            {"text": "🚿 ವೈಯಕ್ತಿಕ ಸ್ವಚ್ಛತೆ", "next_id": "hygiene_personal_kn"},
            {"text": "🏠 ಮನೆ ನೈರ್ಮಲ್ಯ", "next_id": "hygiene_home_kn"},
            {"text": "⬅️ ಸ್ವಚ್ಛತೆಗೆ ಹಿಂತಿರುಗಿ", "next_id": "hygiene_kn"},
        ],
    },
    "dengue_start_kn": {
        "id": "dengue_start_kn",
        "messages": [
            "🦟 <strong>ಡೆಂಗ್ಯೂ ರೋಗದ ಲಕ್ಷಣಗಳು ಮತ್ತು ತಡೆಗಟ್ಟುವಿಕೆ</strong>\n\nಡೆಂಗ್ಯೂ ಎಂಬುದು ಸೋಂಕಿತ Aedes ಸೊಳ್ಳೆಯ ಕಡಿತದಿಂದ ಹರಡುವ ವೈರಲ್ ಸೋಂಕು.",
            "ಏನು ತಿಳಿಯಲು ಬಯಸುತ್ತೀರಿ?",
        ],
        "buttons": [
            {"text": "ಸಾಮಾನ್ಯ ಲಕ್ಷಣಗಳನ್ನು ನೋಡಿ", "next_id": "dengue_symptoms_kn"},
            {"text": "ಡೆಂಗ್ಯೂ ತಡೆಗಟ್ಟುವಿಕೆಯನ್ನು ಕಲಿಯಿರಿ", "next_id": "dengue_prevention_kn"},
        ],
    },
    "dengue_symptoms_kn": {
        "id": "dengue_symptoms_kn",
        "messages": [
            "ಡೆಂಗ್ಯೂದ ಸಾಮಾನ್ಯ ಲಕ್ಷಣಗಳು:",
            "• ಹಠಾತ್ ಹೆಚ್ಚಿನ ಜ್ವರ (104°F / 40°C)\n• ತೀವ್ರ ತಲೆನೋವು, ಕಣ್ಣುಗಳ ಹಿಂದೆ ನೋವು\n• ಸ್ನಾಯು ಮತ್ತು ಕೀಲು ನೋವು\n• ವಾಂತಿ ಅಥವಾ ವಾಂತಿ\n• ಚರ್ಮದ ದದ್ದು",
            "⚠️ <strong>ಮುಖ್ಯ:</strong> ಇದು ಮಾಹಿತಿಗಾಗಿ ಮಾತ್ರ ಮತ್ತು <strong>ವೈದ್ಯಕೀಯ ರೋಗನಿರ್ಣಯವಲ್ಲ</strong>. ನೀವು ಅಥವಾ ನಿಮ್ಮ ಕುಟುಂಬದ ಸದಸ್ಯರಿಗೆ ಈ ಲಕ್ಷಣಗಳು ಇದ್ದರೆ ತಕ್ಷಣ ವೈದ್ಯರನ್ನು ಸಂಪರ್ಕಿಸಿ.",
        ],
        "buttons": [
            {"text": "ತಡೆಗಟ್ಟುವಿಕೆ ಸಲಹೆಗಳನ್ನು ತೋರಿಸಿ", "next_id": "dengue_prevention_kn"},
            {"text": "ಮುಖ್ಯ ಮೆನುಗೆ ಹೋಗಿ", "next_id": "menu_kn"},
        ],
    },
    "dengue_prevention_kn": {
        "id": "dengue_prevention_kn",
        "messages": [
            "ತಡೆಗಟ್ಟುವಿಕೆಯೇ ಉತ್ತಮ ರಕ್ಷಣೆ! ಸೊಳ್ಳೆಗಳು ಸಂತಾನೋತ್ಪತ್ತಿ ಮಾಡುವುದನ್ನು ನಿಲ್ಲಿಸುವ ಮೂಲಕ ನೀವು ಡೆಂಗ್ಯೂವನ್ನು ತಡೆಯಬಹುದು.",
            "1. <strong>ನಿಶ್ಚಲ ನೀರನ್ನು ತೆಗೆದುಹಾಕಿ:</strong> ನೀರಿನ ಕೂಲರ್ಗಳು, ಮಡಕೆಗಳು ಮತ್ತು ಬಕೆಟ್ಗಳನ್ನು ಕನಿಷ್ಠ ವಾರಕ್ಕೊಮ್ಮೆ ಖಾಲಿ ಮಾಡಿ ಮತ್ತು ಸ್ವಚ್ಛಗೊಳಿಸಿ.",
            "2. <strong>ವಿಕರ್ಷಕವನ್ನು ಬಳಸಿ:</strong> ಬಹಿರಂಗ ಚರ್ಮದ ಮೇಲೆ ಸೊಳ್ಳೆ ವಿಕರ್ಷಕವನ್ನು ಅನ್ವಯಿಸಿ.",
            "3. <strong>ರಕ್ಷಣಾತ್ಮಕ ಬಟ್ಟೆಗಳನ್ನು ಧರಿಸಿ:</strong> ಉದ್ದ-ತೋಳಿನ ಶರ್ಟ್ಗಳು ಮತ್ತು ಪ್ಯಾಂಟ್ಗಳನ್ನು ಧರಿಸಿ.",
            "4. <strong>ಸೊಳ್ಳೆ ಬಲೆಗಳನ್ನು ಬಳಸಿ:</strong> ವಿಶೇಷವಾಗಿ ಹಗಲು ಸಮಯದಲ್ಲಿ ಬಲೆಯ ಕೆಳಗೆ ಮಲಗಿ.",
        ],
        "buttons": [
            {"text": "ಮುಖ್ಯ ಮೆನುಗೆ ಹೋಗಿ", "next_id": "menu_kn"},
            {"text": "ಚಾಟ್ ಅನ್ನು ಕೊನೆಗೊಳಿಸಿ", "next_id": "end_kn"},
        ],
    },
    # Emergency Contacts in Kannada
    "emergency_kn": {
        "id": "emergency_kn",
        "messages": [
            "🚨 <strong>ತುರ್ತು ಸಂಪರ್ಕಗಳು</strong>\n\nಆರೋಗ್ಯ ತುರ್ತು ಸಂದರ್ಭಗಳಿಗಾಗಿ ಈ ಮುಖ್ಯ ಸಂಖ್ಯೆಗಳನ್ನು ಉಳಿಸಿ:",
            "📞 <strong>ರಾಷ್ಟ್ರೀಯ ತುರ್ತು ಸಂಖ್ಯೆಗಳು:</strong>\n• <strong>108:</strong> ಆಂಬ್ಯುಲೆನ್ಸ್ ಸೇವೆ\n• <strong>102:</strong> ಆಂಬ್ಯುಲೆನ್ಸ್ ಸೇವೆ (ಪರ್ಯಾಯ)\n• <strong>104:</strong> ಆರೋಗ್ಯ ಹೆಲ್ಪ್ಲೈನ್\n• <strong>1098:</strong> ಮಕ್ಕಳ ಹೆಲ್ಪ್ಲೈನ್",
            "🏥 <strong>ಸ್ಥಳೀಯ ಆರೋಗ್ಯ ಕೇಂದ್ರಗಳು:</strong>\n• ಪ್ರಾಥಮಿಕ ಆರೋಗ್ಯ ಕೇಂದ್ರ (PHC)\n• ಸಮುದಾಯ ಆರೋಗ್ಯ ಕೇಂದ್ರ (CHC)\n• ಜಿಲ್ಲಾ ಆಸ್ಪತ್ರೆ\n• ಸರ್ಕಾರಿ ವೈದ್ಯಕೀಯ ಕಾಲೇಜು",
            "👨‍⚕️ <strong>ತುರ್ತು ಸಂದರ್ಭದಲ್ಲಿ ಕರೆಯಬೇಕಾದಾಗ:</strong>\n• ತೀವ್ರ ಎದೆಯ ನೋವು ಅಥವಾ ಉಸಿರಾಟದ ತೊಂದರೆ\n• ಅಜ್ಞಾನ ಅಥವಾ ತೀವ್ರ ತಲೆಗೆ ಗಾಯ\n• ನಿಲ್ಲದ ತೀವ್ರ ರಕ್ತಸ್ರಾವ\n• ಸ್ಟ್ರೋಕ್ ಚಿಹ್ನೆಗಳು (ಮುಖದ ಕುಸಿತ, ತೋಳಿನ ದೌರ್ಬಲ್ಯ, ಮಾತಿನ ತೊಂದರೆ)\n• ತೀವ್ರ ಅಲರ್ಜಿ ಪ್ರತಿಕ್ರಿಯೆಗಳು\n• ದದ್ದು ಅಥವಾ ಗೊಂದಲದೊಂದಿಗೆ ಹೆಚ್ಚಿನ ಜ್ವರ",
        ],
        "buttons": [
            {"text": "💡 ಆರೋಗ್ಯ ಸಲಹೆಗಳು", "next_id": "tips_kn"},
            {"text": "⬅️ ಮುಖ್ಯ ಮೆನು", "next_id": "menu_kn"},
        ],
    },
    
    # Health Tips in Kannada
    "tips_kn": {
        "id": "tips_kn",
        "messages": [
            "💡 <strong>ದೈನಂದಿನ ಆರೋಗ್ಯ ಸಲಹೆಗಳು</strong>\n\nಉತ್ತಮ ಆರೋಗ್ಯ ಮತ್ತು ಕ್ಷೇಮಕ್ಕಾಗಿ ಸರಳ ಸಲಹೆಗಳು:",
            "🌅 <strong>ಬೆಳಿಗ್ಗೆಯ ದಿನಚರಿ:</strong>\n• ಪ್ರತಿದಿನ ಒಂದೇ ಸಮಯದಲ್ಲಿ ಎದ್ದುಕೊಳ್ಳಿ\n• ಖಾಲಿ ಹೊಟ್ಟೆಯಲ್ಲಿ ಒಂದು ಗ್ಲಾಸ್ ನೀರು ಕುಡಿಯಿರಿ\n• 10 ನಿಮಿಷಗಳ ಸ್ಟ್ರೆಚಿಂಗ್ ಅಥವಾ ಯೋಗ ಅಭ್ಯಾಸ ಮಾಡಿ\n• ಪೋಷಕಾಂಶಗಳಿಂದ ಕೂಡಿದ ಉಪಹಾರ ತೆಗೆದುಕೊಳ್ಳಿ",
            "🥗 <strong>ಪೋಷಣೆ ಸಲಹೆಗಳು:</strong>\n• ದಿನಕ್ಕೆ 5-6 ಸಣ್ಣ ಊಟಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಿ\n• ಪ್ರತಿ ಊಟದಲ್ಲಿ ಹಣ್ಣುಗಳು ಮತ್ತು ತರಕಾರಿಗಳನ್ನು ಸೇರಿಸಿ\n• ದಿನಕ್ಕೆ 8-10 ಗ್ಲಾಸ್ ನೀರು ಕುಡಿಯಿರಿ\n• ಸಂಸ್ಕರಿಸಿದ ಮತ್ತು ಹುರಿದ ಆಹಾರಗಳನ್ನು ಸೀಮಿತಗೊಳಿಸಿ",
            "🏃‍♀️ <strong>ದೈಹಿಕ ಚಟುವಟಿಕೆ:</strong>\n• ದಿನಕ್ಕೆ 30 ನಿಮಿಷಗಳ ವ್ಯಾಯಾಮದ ಗುರಿ ಹೊಂದಿಸಿ\n• ಎಲಿವೇಟರ್ಗಳ ಬದಲು ಮೆಟ್ಟಿಲುಗಳನ್ನು ಬಳಸಿ\n• ಕನಿಷ್ಠ 10,000 ಹೆಜ್ಜೆಗಳು ನಡೆಯಿರಿ\n• ವಾರಕ್ಕೆ 2-3 ಬಾರಿ ಶಕ್ತಿ ತರಬೇತಿಯನ್ನು ಸೇರಿಸಿ",
            "😴 <strong>ನಿದ್ರೆ ಮತ್ತು ವಿಶ್ರಾಂತಿ:</strong>\n• ರಾತ್ರಿಗೆ 7-8 ಗಂಟೆಗಳ ನಿದ್ರೆ ಪಡೆಯಿರಿ\n• ಸ್ಥಿರ ನಿದ್ರೆ ವೇಳಾಪಟ್ಟಿಯನ್ನು ನಿರ್ವಹಿಸಿ\n• ಮಲಗುವ 1 ಗಂಟೆ ಮೊದಲು ಪರದೆಗಳನ್ನು ತಪ್ಪಿಸಿ\n• ಆರಾಮದಾಯಕ ನಿದ್ರೆ ವಾತಾವರಣವನ್ನು ರಚಿಸಿ",
        ],
        "buttons": [
            {"text": "🚨 ತುರ್ತು ಸಂಪರ್ಕಗಳು", "next_id": "emergency_kn"},
            {"text": "⬅️ ಮುಖ್ಯ ಮೆನು", "next_id": "menu_kn"},
        ],
    },
    
    "end_kn": {
        "id": "end_kn",
        "messages": [
            "ಸ್ವಸ್ಥ್ಯ ಸಹಾಯಕವನ್ನು ಬಳಸಿದ್ದಕ್ಕಾಗಿ ಧನ್ಯವಾದಗಳು. ಆರೋಗ್ಯವಾಗಿ ಇರಿ ಮತ್ತು ಜಾಗರೂಕರಾಗಿರಿ! 👋",
        ],
        "buttons": [
            {"text": "ಮರುಪ್ರಾರಂಭಿಸಿ", "next_id": "start"},
        ],
    },
    # Emergency Contacts
    "emergency_en": {
        "id": "emergency_en",
        "messages": [
            "🚨 <strong>Emergency Contacts</strong>\n\nSave these important numbers for health emergencies:",
            "📞 <strong>National Emergency Numbers:</strong>\n• <strong>108:</strong> Ambulance Service\n• <strong>102:</strong> Ambulance Service (Alternative)\n• <strong>104:</strong> Health Helpline\n• <strong>1098:</strong> Child Helpline",
            "🏥 <strong>Local Health Centers:</strong>\n• Primary Health Center (PHC)\n• Community Health Center (CHC)\n• District Hospital\n• Government Medical College",
            "👨‍⚕️ <strong>When to Call Emergency:</strong>\n• Severe chest pain or breathing difficulty\n• Unconsciousness or severe head injury\n• Severe bleeding that won't stop\n• Signs of stroke (facial drooping, arm weakness, speech difficulty)\n• Severe allergic reactions\n• High fever with rash or confusion",
            "💡 <strong>Tips:</strong>\n• Keep emergency numbers saved in your phone\n• Know the location of nearest hospital\n• Keep important medical documents ready\n• Inform family members about your health conditions",
        ],
        "buttons": [
            {"text": "💡 Health Tips", "next_id": "tips_en"},
            {"text": "⬅️ Back to Main Menu", "next_id": "menu_en"},
        ],
    },
    
    # Health Tips
    "tips_en": {
        "id": "tips_en",
        "messages": [
            "💡 <strong>Daily Health Tips</strong>\n\nSimple tips for better health and wellness:",
            "🌅 <strong>Morning Routine:</strong>\n• Wake up at the same time daily\n• Drink a glass of water on empty stomach\n• Practice 10 minutes of stretching or yoga\n• Have a nutritious breakfast",
            "🥗 <strong>Nutrition Tips:</strong>\n• Eat 5-6 small meals throughout the day\n• Include fruits and vegetables in every meal\n• Drink 8-10 glasses of water daily\n• Limit processed and fried foods\n• Don't skip meals",
            "🏃‍♀️ <strong>Physical Activity:</strong>\n• Aim for 30 minutes of exercise daily\n• Take stairs instead of elevators\n• Walk for at least 10,000 steps\n• Include strength training 2-3 times a week\n• Find activities you enjoy",
            "😴 <strong>Sleep & Rest:</strong>\n• Get 7-8 hours of sleep nightly\n• Maintain consistent sleep schedule\n• Avoid screens 1 hour before bed\n• Create a comfortable sleep environment\n• Take short breaks during work",
            "🧘‍♀️ <strong>Mental Health:</strong>\n• Practice deep breathing exercises\n• Spend time in nature\n• Connect with family and friends\n• Limit social media usage\n• Practice gratitude daily",
            "🩺 <strong>Preventive Care:</strong>\n• Regular health check-ups\n• Keep vaccinations up to date\n• Monitor blood pressure and sugar\n• Practice good hygiene\n• Avoid smoking and excessive alcohol",
        ],
        "buttons": [
            {"text": "🚨 Emergency Contacts", "next_id": "emergency_en"},
            {"text": "⬅️ Back to Main Menu", "next_id": "menu_en"},
        ],
    },
    
    "end_en": {
        "id": "end_en",
        "messages": [
            "Thank you for using Swasthya Sahayak. Stay healthy and take care! 👋",
        ],
        "buttons": [
            {"text": "Restart", "next_id": "start"},
        ],
    },
}


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/sms")
def sms_test_page():
    return render_template("sms_test.html")


@app.post("/api/next")
def api_next():
    data = request.get_json(silent=True) or {}
    node_id = data.get("id", "start")
    user_choice = data.get("choice")
    
    # Initialize session if not exists
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())
        session['start_time'] = datetime.now().isoformat()
        session['conversation_path'] = []
    
    # Track conversation
    track_conversation(node_id, user_choice)
    
    # Add to conversation path
    session['conversation_path'].append({
        'node_id': node_id,
        'choice': user_choice,
        'timestamp': datetime.now().isoformat()
    })
    
    node = CONVERSATION.get(node_id)
    if not node:
        # Fallback to start if unknown id is requested
        node = CONVERSATION["start"]
    
    return jsonify(node)

@app.route("/api/analytics")
def api_analytics():
    analytics = load_analytics()
    return jsonify(analytics)

@app.route("/api/session")
def api_session():
    if 'session_id' not in session:
        return jsonify({'session_id': None})
    
    return jsonify({
        'session_id': session['session_id'],
        'start_time': session.get('start_time'),
        'conversation_path': session.get('conversation_path', [])
    })

# SMS Webhook Endpoint
@app.route("/sms/webhook", methods=['POST'])
def sms_webhook():
    """Handle incoming SMS messages from SMS gateway"""
    try:
        data = request.get_json() or request.form.to_dict()
        
        # Extract phone number and message (format may vary by SMS provider)
        phone_number = data.get('from') or data.get('sender') or data.get('phone')
        message = data.get('text') or data.get('message') or data.get('body')
        
        if not phone_number or not message:
            return jsonify({'error': 'Missing phone number or message'}), 400
        
        # Process the SMS message
        response_message = process_sms_message(phone_number, message)
        
        # Return response for SMS gateway to send
        return jsonify({
            'to': phone_number,
            'message': response_message,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# SMS Test Endpoint (for testing without SMS gateway)
@app.route("/sms/test", methods=['POST'])
def sms_test():
    """Test SMS functionality without actual SMS gateway"""
    try:
        data = request.get_json()
        phone_number = data.get('phone')
        message = data.get('message')
        
        if not phone_number or not message:
            return jsonify({'error': 'Missing phone number or message'}), 400
        
        response_message = process_sms_message(phone_number, message)
        
        return jsonify({
            'phone': phone_number,
            'user_message': message,
            'bot_response': response_message,
            'status': 'success'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# SMS Sessions Management
@app.route("/api/sms/sessions")
def api_sms_sessions():
    """Get all SMS sessions (for admin/monitoring)"""
    sessions = load_sms_sessions()
    return jsonify(sessions)

@app.route("/api/sms/sessions/<phone_number>")
def api_sms_session(phone_number):
    """Get specific SMS session"""
    sessions = load_sms_sessions()
    clean_phone = re.sub(r'[^\d]', '', phone_number)
    
    if clean_phone in sessions:
        return jsonify(sessions[clean_phone])
    else:
        return jsonify({'error': 'Session not found'}), 404


if __name__ == "__main__":
    app.run(debug=True)


